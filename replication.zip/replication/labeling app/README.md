# Labeling App
This labeling app is used in the study of "Pattern-based Mining of Opinions in Q&A Websites".

## Requirement
To run this app, you will need to have `Python3` and `flask` package installed.

## File structures
- The source code of the labeling app is in the folder `tagger`.
- Database file is named as `tagger.db` (after initialization), which also located in the folder `tagger`.
- The database schema named as `schema.sql` in the folder `tagger`.
- Files `inject_data.py` and `sentences.txt` are used to dump data into the database.

## App usage
### Initializing database 
In the folder of the `labeling app` folder, use the following commands to initialize the empty database. 
```
export FLASK_APP=tagger/tagger.py
flask initdb
```

### Importing sentences
Then dump the sentences to label into the database.
```
python3 inject_data.py
```
File `sentences.txt` is where to store these sentences.
Please note that to dump the sentences into database, you will need to have to install the package [spaCy](https://spacy.io/) and its English language model.

### Running the labeling app
```
flask run
```
For a detailed explanation of `flask` framework we used, please refer to http://flask.pocoo.org/.
