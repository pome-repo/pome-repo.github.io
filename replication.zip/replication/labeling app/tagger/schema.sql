drop table if exists sentences;
-- sentences to label
create table sentences (
  id integer primary key autoincrement, -- sentence id
  trash_index integer default 0, -- how many times the sentence is discarded
  first_abandon_by text, -- who first discarded the sentence
  'text' text not null -- sentence text
);

drop table if exists tokens;
-- tokens composing the sentences
create table tokens (
  id integer primary key autoincrement,
  sentence_id integer not null,
  token text not null,
  offset integer not null, -- the position of the token in the sentence
  type text not null, -- POS type of the token
  foreign key(sentence_id) references sentences(id)
);


drop table if exists sentence_tags;
-- the labeling done for sentence
create table sentence_tags (
  id integer primary key autoincrement,
  sentence_id integer not null,
  sentiment integer not null,
  aspect text not null,
  remark text,
  offset_min integer, -- start position of the selected part of the sentence
  offset_max integer, -- end position of the selected part of the sentence
  author integer not null,
  foreign key(sentence_id) references sentences(id)
);


drop table if exists notations;
-- the labeling done for tokens in sentences
create table notations (
  id integer primary key autoincrement,
  token_id integer not null,
  new_type text, -- not empty only if the default POS tag is changed by the labeler
  ref_lib integer, -- if the token refers to the library
  same_aspect integer, -- if the token reflects the same aspect of the sentence
  sentiment integer,
  author text,
  foreign key(token_id) references tokens(id)
);


drop table if exists labeler;
-- labeler information
create table labeler (
  id integer primary key autoincrement,
  name text not null,
  gender text not null,
  degree text not null,
  occupation text not null,
  exp text not null
);

