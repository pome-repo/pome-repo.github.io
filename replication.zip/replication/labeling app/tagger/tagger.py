# all the imports
import os
import sqlite3
from flask import Flask, request, session, g, redirect, url_for, abort, \
    render_template, flash

app = Flask(__name__)  # create the application instance :)
app.config.from_object(__name__)  # load config from this file , flaskr.py

# Load default config and override config from an environment variable
app.config.update(dict(
    DATABASE=os.path.join(app.root_path, 'tagger.db'),
    SECRET_KEY='USITAGGER'
))
app.config.from_envvar('TAGGER_SETTINGS', silent=True)


def connect_db():
    """Connects to the specific database."""
    rv = sqlite3.connect(app.config['DATABASE'])
    rv.row_factory = sqlite3.Row
    return rv


def get_db():
    """Opens a new database connection if there is none yet for the
    current application context.
    """
    if not hasattr(g, 'sqlite_db'):
        g.sqlite_db = connect_db()
    return g.sqlite_db


@app.teardown_appcontext
def close_db(error):
    """Closes the database again at the end of the request."""
    if hasattr(g, 'sqlite_db'):
        g.sqlite_db.close()


def init_db():
    db = get_db()
    with app.open_resource('schema.sql', mode='r') as f:
        db.cursor().executescript(f.read())
    db.commit()


@app.cli.command('initdb')
def initdb_command():
    """Initializes the database."""
    init_db()
    print('Initialized the database.')


@app.route('/')
def index():
    return render_template('home.html')


@app.route('/register')
def register():
    data = None
    return render_template('register.html', data=data)


@app.route('/save_user', methods=['GET', 'POST'])
def save_user():
    if request.method == 'POST':
        db = get_db()
        # print(request.form['sentiment'])
        # print(request.form['tags'])
        data = request.form.to_dict()
        record = (data['name'], data['gender'], data['degree'], data['job'], data['exp'])
        db.execute('insert into labeler (name, gender, degree, occupation, exp) values (?, ?, ?, ?, ?)',
                   record)
        db.commit()
    return redirect(url_for('label'))


@app.route('/label')
def label():
    if 'user' in session:
        data = {}
        db = get_db()
        query = """
                    select * from sentences
                    where sentences.trash_index < 2 and 
                    (sentences.first_abandon_by != '%s' or sentences.first_abandon_by IS NULL) and
                    sentences.id not in
                      (select sentence_id from (select sentence_id, count(*) as cnt from sentence_tags
                      group by sentence_id having cnt>1)
                      union select sentence_tags.sentence_id from sentence_tags where author='%s')
                    order by random() limit 1;
                """ % (session['user'], session['user'])
        cur = db.execute(query)
        sentence = cur.fetchone()
        print(sentence)

        if sentence is not None:
            sentence_id = sentence[0]
            sentence_text = sentence[3]
            data['sentence'] = {'id': sentence_id, 'text': sentence_text}
            cur = db.execute('SELECT * FROM tokens where sentence_id = ' + str(sentence_id) + ' ORDER BY id ASC;')
            tokens = []
            for token in cur.fetchall():
                tokens.append({'id': token[0], 'token': token[2], 'pos': token[4], 'offset': token[3]})
            data['tokens'] = tokens
            cur = db.execute('SELECT DISTINCT(aspect) FROM sentence_tags;')
            notations = []
            for notation in cur.fetchall():
                notations += notation[0].split(',')
            data['notations'] = list(set(notations))
        else:
            data['sentence'] = None
        print(data)
        return render_template('label.html', data=data)
    else:
        return render_template('home.html')


@app.route('/login', methods=['GET', 'POST'])
def login():
    if 'user' in session and session['user'] is not None:
        return redirect(url_for('label'))
    if request.method == 'POST':
        if request.form['user']:
            session['user'] = request.form['user']
            flash('You were logged in')
            return redirect(url_for('label'))
    return redirect(url_for('index'))


@app.route('/abandon', methods=['GET', 'POST'])
def abandon_sentence():
    if request.method == 'POST':
        db = get_db()
        sentence_id = request.form['abandon-id']

        db.execute('UPDATE sentences SET trash_index = trash_index + 1, first_abandon_by = "' + session['user'] +
                   '" WHERE id=' + str(sentence_id) + ';')
        db.commit()
        return redirect(url_for('label'))
    return redirect(url_for('index'))


@app.route('/save', methods=['GET', 'POST'])
def save_results():
    if request.method == 'POST':
        db = get_db()
        # print(request.form['sentiment'])
        # print(request.form['tags'])
        data = request.form.to_dict()
        # print(data)

        cur = db.execute('SELECT * FROM tokens where sentence_id=' + str(data['sentence_id']) + ';')
        tokens = {}
        for token in cur.fetchall():
            tokens[str(token[0])] = {'type': token[4], 'offset': token[3]}

        # token_id # new_type # notation # sentiment # author
        db_notations = []
        if data['offset_min'] != '':
            offset_min = int(data['offset_min'])
        else:
            offset_min = 0
        if data['offset_max'] != '':
            offset_max = int(data['offset_max'])
        else:
            offset_max = 99999999

        db.execute('insert into sentence_tags (sentence_id, sentiment, aspect, remark, author, offset_min, offset_max) '
                   'values (?, ?, ?, ?, ?, ?, ?)',
                   [data['sentence_id'], data['sentiment'], data['tags'], data['remarks'], session['user'],
                    int(data['offset_min']), int(data['offset_max'])])

        for key, value in data.items():
            if key[0] == 'c' and key[-4:] == 'type':
                token_id = key[1:].split('_')[0]
                token_offset = tokens[token_id]['offset']
                if offset_min <= token_offset < offset_max:
                    if tokens[token_id]['type'] == data['c' + token_id + '_type']:
                        new_type = None
                    else:
                        new_type = data['c' + token_id + '_type']
                    if 'c' + token_id + '_senti' in data:
                        sentiment = data['c' + token_id + '_senti']
                    else:
                        sentiment = None
                    if 'c' + token_id + '_asp' in data and data['c' + token_id + '_asp'] != '':
                        same_aspect = 1  # data['c'+token_id+'_asp']
                    else:
                        same_aspect = 0  # None
                    if 'c' + token_id + '_lib' in data and data['c' + token_id + '_lib'] != '':
                        ref_lib = 1  # data['c'+token_id+'_lib']
                    else:
                        ref_lib = 0  # None
                    db_notations.append((token_id, new_type, same_aspect, ref_lib, sentiment, session['user']))
        db.executemany(
            'insert into notations (token_id,new_type,same_aspect,ref_lib,sentiment,author) values (?,?,?,?,?,?)',
            db_notations)
        db.commit()
        return redirect(url_for('label'))
    return redirect(url_for('index'))


@app.route('/charts')
def chart():
    db = get_db()
    cur = db.execute('select author, count(id) as cnt from sentence_tags group by author order by cnt desc limit 20;')
    winners = cur.fetchall()
    return render_template('chart.html', winners=winners)


@app.route('/clear_session')
def clear_session():
    if 'user' in session and session['user'] is not None:
        session.pop('user')
    return redirect(url_for('index'))


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)
