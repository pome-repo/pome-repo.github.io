import spacy
import sqlite3

conn = sqlite3.connect('tagger/tagger.db')
c = conn.cursor()
nlp = spacy.load('en')

sentences = [line.strip() for line in open('sentences.txt').readlines()]

# https://spacy.io/api/annotation
pos_tags = {
    'ADJ': 'adjective', #big, old, green, incomprehensible, first
    'ADP': 'adposition', #in, to, during
    'ADV': 'adverb', #very, tomorrow, down, where, there
    'AUX': 'auxiliary',	#is, has (done), will (do), should (do)
    'CONJ':	'conjunction', #and, or, but
    'CCONJ': 'coordinating conjunction', #and, or, but
    'DET': 'determiner', #a, an, the
    'INTJ': 'interjection', #psst, ouch, bravo, hello
    'NOUN': 'noun', #girl, cat, tree, air, beauty
    'NUM': 'numeral', #1, 2017, one, seventy-seven, IV, MMXIV
    'PART': 'particle', #'s, not,
    'PRON': 'pronoun', #I, you, he, she, myself, themselves, somebody
    'PROPN': 'proper noun',	#Mary, John, Londin, NATO, HBO
    'PUNCT': 'punctuation',	#., (, ), ?
    'SCONJ': 'subordinating conjunction', #if, while, that
    'SYM': 'symbol',  #$, %, §, ©, +, −, ×, ÷, =, :), 😝
    'VERB': 'verb', #run, runs, running, eat, ate, eating
    'X': 'other', #sfpksdpsxmsa
    'SPACE': 'space'
}

db_sentences = []
db_tokens = []

sentence_id = 1
token_id = 1
for sentence in sentences:
    db_sentences.append((sentence_id, sentence))
    token_order = 1
    doc = nlp(sentence)
    for token in doc:
        token_index = 0
        token_text = token.text
        token_offset = sentence.index(token_text, token_index)
        token_index = token_offset + len(token_text)
        db_tokens.append((sentence_id, token_text, token.pos_, token_offset))
        token_id += 1
    sentence_id += 1

c.executemany('INSERT INTO sentences(id, text) VALUES (?,?)', db_sentences)
c.executemany('INSERT INTO tokens(sentence_id, token, type, offset) VALUES (?,?,?,?)', db_tokens)
conn.commit()
conn.close()
