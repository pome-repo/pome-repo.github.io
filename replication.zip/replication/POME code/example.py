from aspect_matcher import AspectMatcher

matcher = AspectMatcher()
sentence = 'Its large user community can provide support for new users.'
print(matcher.identify_aspect(sentence))