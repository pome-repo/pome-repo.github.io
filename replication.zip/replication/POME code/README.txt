To run this program, you will need to have the following software/packages installed:
- Python 3
- spacy

For the example usage, please check "example.py".